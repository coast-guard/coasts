#!/usr/bin/env node
//
// Minimal MCP server (JSON-RPC 2.0 over stdio) for coast integration testing.
// Zero external dependencies. Implements the MCP handshake and a single "echo" tool.
//
// Usage:   node server.js
// Smoke:   echo '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"capabilities":{}}}' | node server.js

const readline = require("readline");

const TOOLS = [
  {
    name: "echo",
    description: "Echoes back the provided message",
    inputSchema: {
      type: "object",
      properties: { message: { type: "string" } },
      required: ["message"],
    },
  },
];

function handleRequest(req) {
  switch (req.method) {
    case "initialize":
      return {
        protocolVersion: "2024-11-05",
        capabilities: { tools: {} },
        serverInfo: { name: "mcp-echo", version: "1.0.0" },
      };

    case "notifications/initialized":
      return null;

    case "tools/list":
      return { tools: TOOLS };

    case "tools/call": {
      const toolName = req.params?.name;
      if (toolName !== "echo") {
        return { isError: true, content: [{ type: "text", text: `Unknown tool: ${toolName}` }] };
      }
      const message = req.params?.arguments?.message || "";
      return { content: [{ type: "text", text: message }] };
    }

    default:
      return undefined;
  }
}

const rl = readline.createInterface({ input: process.stdin });

rl.on("line", (line) => {
  let req;
  try {
    req = JSON.parse(line);
  } catch {
    return;
  }

  const result = handleRequest(req);

  if (result === null) return;

  if (result === undefined) {
    const err = { jsonrpc: "2.0", id: req.id, error: { code: -32601, message: "Method not found" } };
    process.stdout.write(JSON.stringify(err) + "\n");
    return;
  }

  const resp = { jsonrpc: "2.0", id: req.id, result };
  process.stdout.write(JSON.stringify(resp) + "\n");
});

if (process.argv.includes("--version")) {
  console.log("mcp-echo 1.0.0");
  process.exit(0);
}

process.stderr.write("mcp-echo: ready (stdio)\n");
