const http = require("http");
const os = require("os");

const PORT = process.env.PORT || 40300;

const server = http.createServer((req, res) => {
  res.writeHead(200, { "Content-Type": "application/json" });
  res.end(
    JSON.stringify({
      message: "Hello from main branch!",
      hostname: os.hostname(),
      uptime: process.uptime(),
    })
  );
});

server.listen(PORT, () => {
  console.log(`File watcher test server listening on port ${PORT}`);
});
