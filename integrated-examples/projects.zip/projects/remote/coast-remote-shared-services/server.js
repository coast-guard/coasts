const http = require("http");
const { execSync } = require("child_process");

const PORT = 40200;

const server = http.createServer((req, res) => {
  if (req.url === "/health") {
    res.writeHead(200, { "Content-Type": "application/json" });
    res.end(JSON.stringify({ status: "ok" }));
    return;
  }

  if (req.url === "/check-postgres") {
    try {
      // Try to connect to postgres via the shared service hostname.
      // The hostname "postgres" should resolve via extra_hosts to the
      // host gateway, where the reverse SSH tunnel forwards to the
      // local machine's postgres container.
      const result = execSync(
        'timeout 5 sh -c \'echo "\\q" | nc postgres 5432\' 2>&1 || true',
        { encoding: "utf8", timeout: 10000 }
      );
      res.writeHead(200, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ postgres_reachable: true, output: result.trim() }));
    } catch (err) {
      res.writeHead(200, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ postgres_reachable: false, error: err.message }));
    }
    return;
  }

  res.writeHead(200, { "Content-Type": "text/plain" });
  res.end("coast-remote-shared-services test app\n");
});

server.listen(PORT, "0.0.0.0", () => {
  console.log(`Server listening on port ${PORT}`);
});
