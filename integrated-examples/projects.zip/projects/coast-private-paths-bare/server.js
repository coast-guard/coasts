const http = require("http");
const fs = require("fs");
const { spawn, execSync } = require("child_process");
const PORT = process.env.PORT || 41000;
const LOCK_PATH = "/workspace/data/app.lock";

// Acquire a persistent flock at startup, mimicking Next.js .next/trace lock.
// Spawns a background `flock -x <file> -c "sleep infinity"` that holds the
// lock for the entire process lifetime. If the old server wasn't killed or
// the private_paths overlay leaked, flock -n will fail.
let lockHeld = false;
let lockChild = null;
try {
  fs.mkdirSync("/workspace/data", { recursive: true });
  // Non-blocking flock test: exit 0 if acquired, exit 1 if held
  execSync(`flock -n "${LOCK_PATH}" true`, { stdio: "ignore" });
  // If we get here, lock is available. Hold it persistently.
  lockChild = spawn("flock", ["-x", LOCK_PATH, "-c", "sleep infinity"], {
    stdio: "ignore", detached: false
  });
  lockHeld = true;
  console.log("Acquired exclusive flock on " + LOCK_PATH);
} catch (e) {
  console.error("FLOCK FAILED: Could not acquire lock on " + LOCK_PATH);
  console.error("This means a stale lock leaked across the workspace remount.");
  // Server starts but reports lock failure
}

process.on("exit", () => { if (lockChild) lockChild.kill(); });

const server = http.createServer((req, res) => {
  if (req.url === "/health") {
    res.writeHead(200); res.end("ok"); return;
  }
  if (req.url === "/lock-status") {
    res.writeHead(200, { "Content-Type": "application/json" });
    res.end(JSON.stringify({ lock_held: lockHeld, lock_path: LOCK_PATH }));
    return;
  }
  res.writeHead(200, { "Content-Type": "application/json" });
  res.end(JSON.stringify({ version: "main", branch: "main", lock_held: lockHeld }));
});

server.listen(PORT, () => console.log("main server on " + PORT));
