const http = require("http");
const { createClient } = require("redis");

const PORT = 3000;

const redisClient = createClient({ url: process.env.REDIS_URL });

async function init() {
  await redisClient.connect();
  console.log("Connected to Redis.");
}

const server = http.createServer(async (req, res) => {
  const json = (data, status = 200) => {
    res.writeHead(status, { "Content-Type": "application/json" });
    res.end(JSON.stringify(data));
  };

  try {
    if (req.url === "/health") {
      return json({ status: "ok" });
    }

    if (req.url === "/redis-info") {
      const marker = await redisClient.get("instance_marker");
      const counter = await redisClient.get("request_counter");
      return json({
        instance_marker: marker,
        request_counter: counter ? parseInt(counter) : 0,
      });
    }

    if (req.url === "/redis-set-marker") {
      await redisClient.set("instance_marker", "main");
      const count = await redisClient.incr("request_counter");
      return json({ marker: "main", request_counter: count });
    }

    // Default: status endpoint
    const count = await redisClient.incr("request_counter");
    return json({
      service: "coast-api",
      message: "API Gateway Ready",
      branch: "main",
      request_count: count,
    });
  } catch (err) {
    console.error("Request error:", err);
    json({ error: err.message }, 500);
  }
});

init()
  .then(() => {
    server.listen(PORT, () => {
      console.log(`Coast API listening on :${PORT}`);
    });
  })
  .catch((err) => {
    console.error("Failed to start:", err);
    process.exit(1);
  });
