const http = require("http");
const { Pool } = require("pg");
const { createClient } = require("redis");

const PORT = 3000;

const pgPool = new Pool({
  connectionString: process.env.DATABASE_URL,
  connectionTimeoutMillis: 3000,
});
const redisClient = createClient({
  url: process.env.REDIS_URL,
  socket: { connectTimeout: 3000 },
});

redisClient.on("error", (err) => {
  console.error("redis client error:", err.message);
});

async function probePostgres() {
  const r = await pgPool.query("SELECT 1 AS ok");
  return r.rows[0];
}

async function probeRedis() {
  if (!redisClient.isOpen) {
    await redisClient.connect();
  }
  await redisClient.set("coast_reboot_marker", "ok");
  return await redisClient.get("coast_reboot_marker");
}

const server = http.createServer(async (req, res) => {
  const json = (data, status = 200) => {
    res.writeHead(status, { "Content-Type": "application/json" });
    res.end(JSON.stringify(data));
  };

  try {
    if (req.url === "/health") {
      return json({
        status: "ok",
        app_name: process.env.APP_NAME || null,
        app_marker: process.env.APP_MARKER || null,
      });
    }
    if (req.url === "/db-check") {
      const row = await probePostgres();
      return json({ db: "connected", result: row });
    }
    if (req.url === "/cache-check") {
      const val = await probeRedis();
      return json({ cache: "connected", value: val });
    }
    if (req.url === "/full-check") {
      const row = await probePostgres();
      const val = await probeRedis();
      return json({ db: "connected", row, cache: "connected", value: val });
    }
    return json({ message: "coast-reboot-recovery app" });
  } catch (err) {
    console.error("request error:", err.message);
    json({ error: err.message }, 500);
  }
});

server.listen(PORT, () =>
  console.log(`coast-reboot-recovery listening on :${PORT}`)
);
